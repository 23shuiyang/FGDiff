# FGiff
## Fixation-Guided Diffusion for Salient Object Detection in Optical Remote Sensing Images



